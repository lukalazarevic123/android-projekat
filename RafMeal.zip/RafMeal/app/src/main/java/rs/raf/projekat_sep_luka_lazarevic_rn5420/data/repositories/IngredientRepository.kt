package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.IngredientEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Ingredient
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single

interface IngredientRepository {

    fun getIngredients() : Observable<List<Ingredient>>

    fun insert(ingredientEntity: IngredientEntity) : Completable
    fun insertAll(ingredientEntities : List<IngredientEntity>) : Single<List<Long>>
    fun getAll() : Observable<List<IngredientEntity>>
    fun getById(id : Long) :  Observable<List<IngredientEntity>>
    fun getByName(name : String) : Observable<List<IngredientEntity>>
    fun deleteAll() : Completable
}