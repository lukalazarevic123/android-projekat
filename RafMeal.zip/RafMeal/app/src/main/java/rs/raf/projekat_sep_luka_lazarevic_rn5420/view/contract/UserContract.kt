package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract

import androidx.lifecycle.LiveData
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.UserEntity

interface UserContract {
    interface UserViewModel {

        val fetchedUser : LiveData<UserEntity>

        fun insert(userEntity: UserEntity)
        fun insertAll(userEntities : List<UserEntity>)
        fun getAll()
        fun getById(id : String, pass : String)
        fun deleteAll()
    }
}