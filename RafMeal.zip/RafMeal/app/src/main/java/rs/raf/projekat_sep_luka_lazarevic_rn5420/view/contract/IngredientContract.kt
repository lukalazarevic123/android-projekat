package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract

import androidx.lifecycle.LiveData
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.IngredientEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Ingredient

interface IngredientContract {
    interface IngredientViewModel {
        val ingredients : LiveData<List<Ingredient>>

        fun getIngredients()
        fun insert(ingredientEntity: IngredientEntity)
        fun insertAll(ingredientEntities : List<IngredientEntity>)
        fun getAll()
        fun getById(id : Long)
        fun getByName(name : String)
        fun deleteAll()
    }
}