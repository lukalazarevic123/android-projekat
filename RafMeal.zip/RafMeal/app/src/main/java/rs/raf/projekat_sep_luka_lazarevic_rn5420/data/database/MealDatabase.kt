package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.database.converters.DateConverter
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.daos.IngredientDao
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.daos.MealDao
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.daos.UserDao
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.IngredientEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.MealEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.UserEntity

@Database(
    entities = [UserEntity::class, MealEntity::class, IngredientEntity::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(DateConverter::class)
abstract class MealDatabase : RoomDatabase() {
    abstract fun getUserDao() : UserDao
    abstract fun getMealDao() : MealDao
    abstract fun getIngredientDao() : IngredientDao
}