package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Area
import io.reactivex.Observable

interface AreaRepository {

    fun getAreas() : Observable<List<Area>>

}