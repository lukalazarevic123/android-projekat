package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Area
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.AreaRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract.AreaContract
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class AreaViewModel(private val areaRepository: AreaRepository) : ViewModel(), AreaContract.AreaViewModel{
    override val areas: MutableLiveData<List<Area>> = MutableLiveData()

    private val subscriptions = CompositeDisposable()

    override fun getAreas() {
        val subscription =
            areaRepository.getAreas().subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(
                {
                    areas.value = it
                },
                {
                    println(it)
                },
                {
                    println("COMPLETED")
                }
            )

        subscriptions.add(subscription)
    }

    override fun onCleared(){
        subscriptions.dispose()
        super.onCleared()
    }
}