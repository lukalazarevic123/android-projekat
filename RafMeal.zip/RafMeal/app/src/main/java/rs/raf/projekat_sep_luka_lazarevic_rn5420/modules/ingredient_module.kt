package rs.raf.projekat_sep_luka_lazarevic_rn5420.modules

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.database.MealDatabase
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.IngredientDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.IngredientRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation.IngredientRepositoryImpl
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.IngredientViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val ingredientModule = module {
    viewModel {IngredientViewModel(ingredientRepository = get())}

    single<IngredientRepository> {IngredientRepositoryImpl(ingredientDao = get(), ingredientDataSource = get())}

    single<IngredientDataSource> {create(get())}

    single {get<MealDatabase>().getIngredientDao()}
}