package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities

data class PlanHolder(
    val mealName : String,
    val day : String,
    val mealType : String
)
