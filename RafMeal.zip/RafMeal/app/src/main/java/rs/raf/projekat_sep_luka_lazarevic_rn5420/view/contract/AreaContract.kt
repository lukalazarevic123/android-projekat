package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract

import androidx.lifecycle.LiveData
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Area

interface AreaContract {
    interface AreaViewModel {
        val areas : LiveData<List<Area>>

        fun getAreas()
    }
}