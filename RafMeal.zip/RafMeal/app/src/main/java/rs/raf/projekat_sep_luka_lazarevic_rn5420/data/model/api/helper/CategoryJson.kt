package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.helper

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CategoryJson(
    val idCategory: String,
    val strCategory: String,
    val strCategoryThumb: String,
    val strCategoryDescription: String
)