package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.responses.IngredientResponse
import io.reactivex.Observable
import retrofit2.http.GET

interface IngredientDataSource {
    @GET("list.php?i=list")
    fun getIngredients() : Observable<IngredientResponse>
}