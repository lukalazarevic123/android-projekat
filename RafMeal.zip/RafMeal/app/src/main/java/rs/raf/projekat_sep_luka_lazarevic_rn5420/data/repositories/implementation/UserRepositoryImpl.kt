package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.daos.UserDao
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.UserEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.UserRepository
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single

class UserRepositoryImpl(private val userDao: UserDao) : UserRepository {
    override fun insert(userEntity: UserEntity): Completable {
        return userDao.insertUser(userEntity)
    }

    override fun insertAll(userEntities: List<UserEntity>): Single<List<Long>> {
        return userDao.insertUsers(userEntities)
    }

    override fun getAll(): Observable<List<UserEntity>> {
        return userDao.getAll()
    }

    override fun deleteAll(): Completable {
        return userDao.deleteAll()
    }

    override fun getById(id: String, pass : String): Observable<UserEntity> {
        return userDao.getById(id, pass);
    }
}