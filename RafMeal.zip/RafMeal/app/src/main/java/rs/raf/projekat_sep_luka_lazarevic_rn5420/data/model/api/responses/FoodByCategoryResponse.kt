package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.responses

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.helper.FoodByCategoryJson
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class FoodByCategoryResponse(
    val meals : List<FoodByCategoryJson>
)
