package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import rs.raf.projekat_sep_luka_lazarevic_rn5420.R
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.UserEntity
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract.MealContract
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract.UserContract
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.MealViewModel
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.UserViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

class SplashActivity : AppCompatActivity() {

    private val userViewModel : UserContract.UserViewModel by viewModel<UserViewModel>()
    private val mealsViewModel : MealContract.MealViewModel by viewModel<MealViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initObservers()
        makeFirstuser()

        supportActionBar?.hide();

        Handler().postDelayed({
            val homeScreen = Intent(this@SplashActivity, HomeActivity::class.java)
            val loginIntent = Intent(this@SplashActivity, LoginActivity::class.java)

            if(checkLogin(context = this.applicationContext)){
                startActivity(homeScreen)
            }else{
                startActivity(loginIntent)
            }

        }, 1000)
    }

    private fun makeFirstuser(){
        val list = mutableListOf(
            UserEntity(
                username = "user123",
                password = "pass123",
                email = "llazarevic5420rn@raf.rs",
                firstName = "Luka",
                lastName = "Lazarevic",
                profilePicture = "abc.png"
            )
        )
        userViewModel.insertAll(list)
    }

    private fun checkLogin(context: Context): Boolean{
        val sharedPreferences: SharedPreferences = context.getSharedPreferences("myPrefs", Context.MODE_PRIVATE)
        val userID: String = sharedPreferences.getString("userID", "").toString()

        return !(userID.isEmpty() || userID.trim() == "")
    }

    private fun initObservers() = with(mealsViewModel) {
        fetchDbMeal.observe(this@SplashActivity) { meal ->
            println("ID ${meal.id}")
        }
    }
}