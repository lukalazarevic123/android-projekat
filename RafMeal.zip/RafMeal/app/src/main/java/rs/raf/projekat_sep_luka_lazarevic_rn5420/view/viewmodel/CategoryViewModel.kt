package rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.CategoryRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Category
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.contract.CategoryContract
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class CategoryViewModel(private val categoryRepository: CategoryRepository) : ViewModel(),
    CategoryContract.CategoryViewModel {

    override val categories: MutableLiveData<List<Category>> = MutableLiveData()
    override val category: MutableLiveData<Category> = MutableLiveData()

    private val subscriptions = CompositeDisposable()

    override fun getCategories() {
        val subscription =
            categoryRepository.getCategories().subscribeOn(Schedulers.io()).observeOn(
                AndroidSchedulers.mainThread()
            ).subscribe(
                {
                    categories.value = it
                },
                {
                    println(it)
                },
                {
                    println("COMPLETED")
                }
            )
        subscriptions.add(subscription)
    }

    override fun onCleared() {
        subscriptions.dispose()
        super.onCleared()
    }
}