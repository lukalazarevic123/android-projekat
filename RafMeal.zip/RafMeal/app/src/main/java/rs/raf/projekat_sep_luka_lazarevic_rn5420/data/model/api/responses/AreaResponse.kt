package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.responses

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.helper.AreaJson
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AreaResponse(
    val meals : List<AreaJson>
)
