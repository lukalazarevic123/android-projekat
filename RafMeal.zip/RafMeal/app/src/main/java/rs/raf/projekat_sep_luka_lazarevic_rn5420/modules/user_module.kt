package rs.raf.projekat_sep_luka_lazarevic_rn5420.modules

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.database.MealDatabase
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.UserRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation.UserRepositoryImpl
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.UserViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val user_module = module {
    viewModel { UserViewModel(userRepository = get()) }

    single<UserRepository> {UserRepositoryImpl(get())}

    single {get<MealDatabase>().getUserDao()}
}