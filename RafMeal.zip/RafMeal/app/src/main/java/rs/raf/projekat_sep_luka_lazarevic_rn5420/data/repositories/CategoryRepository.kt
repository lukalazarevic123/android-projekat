package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Category
import io.reactivex.Observable

interface CategoryRepository {

    fun getCategories() : Observable<List<Category>>
}