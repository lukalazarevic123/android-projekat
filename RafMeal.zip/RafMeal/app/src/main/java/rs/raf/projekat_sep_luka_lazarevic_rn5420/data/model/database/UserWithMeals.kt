package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database

import androidx.room.Embedded
import androidx.room.Relation

data class UserWithMeals(
    @Embedded val user : UserEntity,
    @Relation(
        parentColumn = "username",
        entityColumn = "userId",
        entity = MealEntity::class
    )

    val meals : List<MealForMenu>
)
