package rs.raf.projekat_sep_luka_lazarevic_rn5420.modules

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.database.MealDatabase
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.MealDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.MealRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation.MealRepositoryImpl
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.MealViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module


val mealModule = module {
    viewModel { MealViewModel(mealRepository = get()) }

    single<MealRepository> { MealRepositoryImpl(mealDao = get(),mealDataSource = get()) }

    single<MealDataSource> { create(get()) }

    single {get<MealDatabase>().getMealDao()}
}