package rs.raf.projekat_sep_luka_lazarevic_rn5420.modules

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.AreaDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.AreaRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation.AreaRepositoryImpl
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.AreaViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val areaModule = module {
    viewModel {AreaViewModel(areaRepository = get())}

    single<AreaRepository> {AreaRepositoryImpl(areaDataSource = get())}

    single<AreaDataSource> {create(get())}
}