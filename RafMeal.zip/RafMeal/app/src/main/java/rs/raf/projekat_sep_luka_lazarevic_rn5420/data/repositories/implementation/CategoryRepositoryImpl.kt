package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.CategoryDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.CategoryRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Category
import io.reactivex.Observable

class CategoryRepositoryImpl(private val categoryDataSource: CategoryDataSource) :
    CategoryRepository {
    override fun getCategories(): Observable<List<Category>> {
        return categoryDataSource.getCategories()
            .map {categoryListResponse ->
                categoryListResponse.categories.map { categoryTwo ->
                    Category (
                        id = categoryTwo.idCategory.toLong(),
                        categoryName = categoryTwo.strCategory,
                        categoryDescription = categoryTwo.strCategoryDescription,
                        categoryThumbnail = categoryTwo.strCategoryThumb
                    )
                }
            }
    }
}