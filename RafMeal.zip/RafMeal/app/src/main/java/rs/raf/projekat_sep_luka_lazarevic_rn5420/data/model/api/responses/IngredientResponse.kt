package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.responses

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.helper.IngredientJson
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class IngredientResponse(
    val meals : List<IngredientJson>
)
