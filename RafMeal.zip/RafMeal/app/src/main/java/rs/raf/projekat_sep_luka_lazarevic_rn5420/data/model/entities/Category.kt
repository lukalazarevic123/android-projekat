package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities

class Category(
    val id: Long,
    val categoryName: String,
    val categoryDescription: String,
    val categoryThumbnail: String
    ) {

}