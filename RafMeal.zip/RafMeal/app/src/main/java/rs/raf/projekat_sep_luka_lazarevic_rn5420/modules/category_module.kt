package rs.raf.projekat_sep_luka_lazarevic_rn5420.modules

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.CategoryDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.CategoryRepository
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation.CategoryRepositoryImpl
import rs.raf.projekat_sep_luka_lazarevic_rn5420.view.viewmodel.CategoryViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val categoryModule = module {
    viewModel { CategoryViewModel(categoryRepository = get()) }

    single<CategoryRepository> { CategoryRepositoryImpl(categoryDataSource = get()) }

    single<CategoryDataSource> { create(get()) }
}