package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities

class MealShort(
    val id : Long,
    val mealTitle : String,
    val mealThumbnail : String
    ) {

}