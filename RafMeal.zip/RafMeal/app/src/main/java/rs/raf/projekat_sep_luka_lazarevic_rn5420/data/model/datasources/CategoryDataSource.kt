package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.api.responses.CategoryResponse
import io.reactivex.Observable
import retrofit2.http.GET

interface CategoryDataSource {
    @GET("categories.php")
    fun getCategories() : Observable<CategoryResponse>
}