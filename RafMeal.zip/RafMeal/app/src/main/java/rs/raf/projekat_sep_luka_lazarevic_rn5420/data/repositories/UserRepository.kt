package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.database.UserEntity
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.Single

interface UserRepository {

    fun insert(userEntity: UserEntity) : Completable
    fun insertAll(userEntities : List<UserEntity>) : Single<List<Long>>
    fun getAll() : Observable<List<UserEntity>>
    fun deleteAll() : Completable
    fun getById(id: String, pass: String) : Observable<UserEntity>
}