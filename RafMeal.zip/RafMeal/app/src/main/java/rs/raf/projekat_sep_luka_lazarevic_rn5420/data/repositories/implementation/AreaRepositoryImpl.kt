package rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.implementation

import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.datasources.AreaDataSource
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.model.entities.Area
import rs.raf.projekat_sep_luka_lazarevic_rn5420.data.repositories.AreaRepository
import io.reactivex.Observable

class AreaRepositoryImpl(private val areaDataSource : AreaDataSource) : AreaRepository {
    override fun getAreas(): Observable<List<Area>> {
        return areaDataSource.getAreas().map {areasResponse ->
            areasResponse.meals.map {area ->
                Area(
                    areaName = area.strArea
                )
            }
        }
    }
}